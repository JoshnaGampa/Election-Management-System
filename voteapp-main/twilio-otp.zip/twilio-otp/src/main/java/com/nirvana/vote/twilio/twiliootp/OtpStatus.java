package com.nirvana.vote.twilio.twiliootp;

public enum OtpStatus {
    DELIVERED,FAILED
}
