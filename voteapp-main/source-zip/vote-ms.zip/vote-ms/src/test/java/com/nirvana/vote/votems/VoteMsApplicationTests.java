package com.nirvana.vote.votems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoteMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
