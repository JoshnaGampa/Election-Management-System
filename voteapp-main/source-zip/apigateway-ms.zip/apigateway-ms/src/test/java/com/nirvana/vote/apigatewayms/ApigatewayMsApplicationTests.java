package com.nirvana.vote.apigatewayms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApigatewayMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
