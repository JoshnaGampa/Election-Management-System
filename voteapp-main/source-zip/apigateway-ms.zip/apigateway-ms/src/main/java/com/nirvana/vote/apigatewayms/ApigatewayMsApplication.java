package com.nirvana.vote.apigatewayms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApigatewayMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApigatewayMsApplication.class, args);
	}

}
