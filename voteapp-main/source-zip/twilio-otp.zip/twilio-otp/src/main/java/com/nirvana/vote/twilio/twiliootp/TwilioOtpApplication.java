package com.nirvana.vote.twilio.twiliootp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwilioOtpApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwilioOtpApplication.class, args);
	}

}
