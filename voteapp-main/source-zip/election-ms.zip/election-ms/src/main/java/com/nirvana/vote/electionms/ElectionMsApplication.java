package com.nirvana.vote.electionms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectionMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectionMsApplication.class, args);
	}

}
