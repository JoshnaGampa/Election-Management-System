package com.nirvana.vote.electionms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectionMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
