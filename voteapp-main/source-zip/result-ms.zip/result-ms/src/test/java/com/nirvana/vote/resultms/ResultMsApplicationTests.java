package com.nirvana.vote.resultms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResultMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
