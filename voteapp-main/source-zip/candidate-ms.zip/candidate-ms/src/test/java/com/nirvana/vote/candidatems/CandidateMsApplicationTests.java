package com.nirvana.vote.candidatems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CandidateMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
