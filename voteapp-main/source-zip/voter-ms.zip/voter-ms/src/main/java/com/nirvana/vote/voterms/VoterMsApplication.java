package com.nirvana.vote.voterms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoterMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoterMsApplication.class, args);
	}

}
